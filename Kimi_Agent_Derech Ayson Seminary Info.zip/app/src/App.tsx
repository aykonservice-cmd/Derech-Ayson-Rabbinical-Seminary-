import { useEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { 
  BookOpen, 
  GraduationCap, 
  Users, 
  MapPin, 
  Phone, 
  Mail, 
  ChevronRight,
  Menu,
  X,
  ScrollText,
  Building2
} from 'lucide-react'
import './App.css'

gsap.registerPlugin(ScrollTrigger)

function App() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)
  const programsRef = useRef<HTMLDivElement>(null)
  const admissionsRef = useRef<HTMLDivElement>(null)
  const contactRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    // Hero animations
    const heroTl = gsap.timeline({ delay: 0.3 })
    heroTl
      .fromTo('.hero-bg', 
        { scale: 1.2 }, 
        { scale: 1, duration: 2.5, ease: 'power2.out' }
      )
      .fromTo('.hero-title span', 
        { y: '100%', opacity: 0 }, 
        { y: '0%', opacity: 1, duration: 1.5, stagger: 0.05, ease: 'power3.out' }, 
        '-=2'
      )
      .fromTo('.hero-subtitle', 
        { opacity: 0, filter: 'blur(10px)' }, 
        { opacity: 1, filter: 'blur(0px)', duration: 1.2, ease: 'power2.out' }, 
        '-=1'
      )
      .fromTo('.hero-buttons', 
        { y: 40, opacity: 0 }, 
        { y: 0, opacity: 1, duration: 1, ease: 'power3.out' }, 
        '-=0.8'
      )

    // Hero parallax on scroll
    gsap.to('.hero-bg', {
      yPercent: 30,
      ease: 'none',
      scrollTrigger: {
        trigger: heroRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: true,
      }
    })

    gsap.to('.hero-content', {
      opacity: 0,
      filter: 'blur(10px)',
      ease: 'none',
      scrollTrigger: {
        trigger: heroRef.current,
        start: 'top top',
        end: '50% top',
        scrub: true,
      }
    })

    // About section animations
    gsap.fromTo('.about-image', 
      { clipPath: 'inset(0 100% 0 0)' },
      {
        clipPath: 'inset(0 0% 0 0)',
        duration: 1.5,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: aboutRef.current,
          start: 'top 70%',
          toggleActions: 'play none none none',
        }
      }
    )

    gsap.fromTo('.about-title',
      { x: -50, opacity: 0 },
      {
        x: 0,
        opacity: 1,
        duration: 1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: aboutRef.current,
          start: 'top 60%',
          toggleActions: 'play none none none',
        }
      }
    )

    gsap.fromTo('.about-text',
      { y: 30, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: aboutRef.current,
          start: 'top 50%',
          toggleActions: 'play none none none',
        }
      }
    )

    // Stats counter animation
    const statElements = document.querySelectorAll('.stat-number')
    statElements.forEach((stat) => {
      const target = parseInt(stat.getAttribute('data-target') || '0')
      gsap.fromTo(stat,
        { innerText: 0 },
        {
          innerText: target,
          duration: 2,
          ease: 'power2.out',
          snap: { innerText: 1 },
          scrollTrigger: {
            trigger: stat,
            start: 'top 80%',
            toggleActions: 'play none none none',
          }
        }
      )
    })

    // Programs section
    gsap.fromTo('.program-card',
      { y: 100, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        stagger: 0.2,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: programsRef.current,
          start: 'top 60%',
          toggleActions: 'play none none none',
        }
      }
    )

    // Admissions timeline
    gsap.fromTo('.timeline-line',
      { height: '0%' },
      {
        height: '100%',
        duration: 2,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: admissionsRef.current,
          start: 'top 60%',
          end: 'bottom 80%',
          scrub: true,
        }
      }
    )

    gsap.fromTo('.timeline-item',
      { x: -50, opacity: 0 },
      {
        x: 0,
        opacity: 1,
        duration: 0.8,
        stagger: 0.3,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: admissionsRef.current,
          start: 'top 50%',
          toggleActions: 'play none none none',
        }
      }
    )

    // Contact section
    gsap.fromTo('.contact-form',
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: contactRef.current,
          start: 'top 60%',
          toggleActions: 'play none none none',
        }
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill())
    }
  }, [])

  const scrollToSection = (ref: React.RefObject<HTMLDivElement | null>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' })
    setIsMobileMenuOpen(false)
  }

  return (
    <div className="relative min-h-screen bg-cream">
      {/* Grain overlay */}
      <div className="grain-overlay" />

      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'py-3 px-4 md:px-8' 
          : 'py-6 px-4 md:px-8'
      }`}>
        <div className={`mx-auto transition-all duration-500 ${
          isScrolled 
            ? 'max-w-6xl glass rounded-full px-6 py-3' 
            : 'max-w-7xl'
        }`}>
          <div className="flex items-center justify-between">
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
              className={`font-display text-xl md:text-2xl font-semibold transition-colors ${
                isScrolled ? 'text-cream' : 'text-white'
              }`}
            >
              Derech Ayson
            </a>

            {/* Desktop Navigation */}
            <div className={`hidden md:flex items-center gap-8 ${
              isScrolled ? 'text-cream' : 'text-white'
            }`}>
              <button 
                onClick={() => scrollToSection(aboutRef)}
                className="font-body text-sm hover:opacity-70 transition-opacity relative group"
              >
                About
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-current transition-all group-hover:w-full" />
              </button>
              <button 
                onClick={() => scrollToSection(programsRef)}
                className="font-body text-sm hover:opacity-70 transition-opacity relative group"
              >
                Programs
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-current transition-all group-hover:w-full" />
              </button>
              <button 
                onClick={() => scrollToSection(admissionsRef)}
                className="font-body text-sm hover:opacity-70 transition-opacity relative group"
              >
                Admissions
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-current transition-all group-hover:w-full" />
              </button>
              <button 
                onClick={() => scrollToSection(contactRef)}
                className="font-body text-sm hover:opacity-70 transition-opacity relative group"
              >
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-current transition-all group-hover:w-full" />
              </button>
              <button 
                onClick={() => scrollToSection(admissionsRef)}
                className={`px-5 py-2 rounded-full font-body text-sm font-medium transition-all ${
                  isScrolled 
                    ? 'bg-cream text-forest hover:bg-white' 
                    : 'bg-white/20 text-white hover:bg-white/30 backdrop-blur-sm'
                }`}
              >
                Apply Now
              </button>
            </div>

            {/* Mobile menu button */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`md:hidden p-2 ${isScrolled ? 'text-cream' : 'text-white'}`}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-full left-4 right-4 mt-2 glass rounded-2xl p-6">
            <div className="flex flex-col gap-4 text-cream">
              <button 
                onClick={() => scrollToSection(aboutRef)}
                className="font-body text-left py-2 hover:opacity-70 transition-opacity"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection(programsRef)}
                className="font-body text-left py-2 hover:opacity-70 transition-opacity"
              >
                Programs
              </button>
              <button 
                onClick={() => scrollToSection(admissionsRef)}
                className="font-body text-left py-2 hover:opacity-70 transition-opacity"
              >
                Admissions
              </button>
              <button 
                onClick={() => scrollToSection(contactRef)}
                className="font-body text-left py-2 hover:opacity-70 transition-opacity"
              >
                Contact
              </button>
              <button 
                onClick={() => scrollToSection(admissionsRef)}
                className="bg-cream text-forest px-5 py-3 rounded-full font-body text-sm font-medium mt-2"
              >
                Apply Now
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} className="relative h-screen w-full overflow-hidden">
        <div className="hero-bg absolute inset-0 animate-slow-zoom">
          <img 
            src="/hero-bg.jpg" 
            alt="Students at Derech Ayson" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/60" />
        </div>

        <div className="hero-content relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
          <h1 className="hero-title font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl text-white font-medium mb-6 overflow-hidden">
            {'Derech Ayson'.split('').map((char, i) => (
              <span key={i} className="inline-block">{char === ' ' ? '\u00A0' : char}</span>
            ))}
            <br />
            {'Rabbinical Seminary'.split('').map((char, i) => (
              <span key={i} className="inline-block">{char === ' ' ? '\u00A0' : char}</span>
            ))}
          </h1>
          
          <p className="hero-subtitle font-display text-lg sm:text-xl md:text-2xl text-white/90 italic mb-4 max-w-2xl">
            Cultivating Torah Scholarship & Ethical Leadership
          </p>
          
          <p className="hero-subtitle font-body text-sm sm:text-base text-white/70 max-w-xl mb-10">
            A premier institution dedicated to the intensive study of Talmud and the development 
            of future Jewish leaders in the Novardok tradition.
          </p>

          <div className="hero-buttons flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => scrollToSection(programsRef)}
              className="magnetic-btn px-8 py-4 bg-white text-forest rounded-full font-body text-sm font-medium hover:bg-cream transition-colors"
            >
              Explore Our Programs
            </button>
            <button 
              onClick={() => scrollToSection(contactRef)}
              className="magnetic-btn px-8 py-4 border-2 border-white text-white rounded-full font-body text-sm font-medium hover:bg-white/10 transition-colors"
            >
              Contact Us
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-white/70 rounded-full" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section ref={aboutRef} className="py-20 md:py-32 px-4 md:px-8 bg-cream">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-12 gap-8 md:gap-12 items-center">
            {/* Image */}
            <div className="md:col-span-7 relative">
              <div className="about-image relative overflow-hidden rounded-2xl shadow-elevated">
                <img 
                  src="/about-img.jpg" 
                  alt="Students walking together" 
                  className="w-full h-[400px] md:h-[600px] object-cover"
                />
              </div>
              {/* Decorative element */}
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-sage/20 rounded-full -z-10" />
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-forest/10 rounded-full -z-10" />
            </div>

            {/* Content */}
            <div className="md:col-span-5 md:-ml-12 relative z-10">
              <div className="bg-cream/90 backdrop-blur-sm p-8 md:p-12 rounded-2xl">
                <span className="about-title inline-block text-sage font-body text-sm uppercase tracking-widest mb-4">
                  About Our Yeshiva
                </span>
                <h2 className="about-title font-display text-3xl md:text-4xl lg:text-5xl text-forest font-medium mb-6">
                  Rooted in Tradition, Committed to Excellence
                </h2>
                <p className="about-text font-body text-forest/70 leading-relaxed mb-8">
                  For decades, Derech Ayson has stood as a beacon of Torah learning in the Novardok 
                  tradition. Our intensive Talmudic studies program develops scholars with a lifelong 
                  commitment to Jewish law, ethics, and leadership.
                </p>
                <p className="about-text font-body text-forest/70 leading-relaxed mb-10">
                  Founded by Rabbi Yechiel Yitzchok Perr and Rabbi Nachman Bulman, our yeshiva 
                  continues to nurture the next generation of Torah leaders under the guidance of 
                  Rabbi Moshe Perr.
                </p>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="stat-number font-display text-3xl md:text-4xl text-forest font-semibold" data-target="60">
                      0
                    </div>
                    <div className="font-body text-xs text-forest/60 mt-1">Students</div>
                  </div>
                  <div className="text-center">
                    <div className="stat-number font-display text-3xl md:text-4xl text-forest font-semibold" data-target="4">
                      0
                    </div>
                    <div className="font-body text-xs text-forest/60 mt-1">Year Program</div>
                  </div>
                  <div className="text-center">
                    <div className="font-display text-3xl md:text-4xl text-forest font-semibold">
                      <ScrollText className="inline-block w-8 h-8" />
                    </div>
                    <div className="font-body text-xs text-forest/60 mt-1">Kollel</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Programs Section */}
      <section ref={programsRef} className="py-20 md:py-32 px-4 md:px-8 bg-forest">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="inline-block text-sage font-body text-sm uppercase tracking-widest mb-4">
              Our Programs
            </span>
            <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-cream font-medium">
              Pathways of Learning
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {/* Program 1 */}
            <div className="program-card group relative bg-forest border border-sage/30 rounded-2xl overflow-hidden hover:border-sage/60 transition-all duration-500">
              <div className="p-8 md:p-10">
                <div className="w-14 h-14 bg-sage/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-sage/30 transition-colors">
                  <BookOpen className="w-7 h-7 text-sage" />
                </div>
                <h3 className="font-display text-2xl md:text-3xl text-cream font-medium mb-4">
                  Beis Medrash
                </h3>
                <p className="font-body text-cream/70 leading-relaxed mb-6">
                  Intensive Talmudic study for post-high school students. Our comprehensive 
                  curriculum builds strong analytical skills and deep Torah knowledge.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Talmud Intensive (5 credits/term)
                  </li>
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Talmud Research (5 credits/term)
                  </li>
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Talmud Survey (2 credits/term)
                  </li>
                </ul>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-sage/0 via-sage to-sage/0 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            </div>

            {/* Program 2 */}
            <div className="program-card group relative bg-forest border border-sage/30 rounded-2xl overflow-hidden hover:border-sage/60 transition-all duration-500">
              <div className="p-8 md:p-10">
                <div className="w-14 h-14 bg-sage/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-sage/30 transition-colors">
                  <GraduationCap className="w-7 h-7 text-sage" />
                </div>
                <h3 className="font-display text-2xl md:text-3xl text-cream font-medium mb-4">
                  Kollel Ner Rochel Leah
                </h3>
                <p className="font-body text-cream/70 leading-relaxed mb-6">
                  Advanced learning program for married students, providing continued 
                  growth in Torah scholarship and preparation for community leadership.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Advanced Talmud Study
                  </li>
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Halacha Seminars
                  </li>
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Community Leadership Training
                  </li>
                </ul>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-sage/0 via-sage to-sage/0 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            </div>

            {/* Program 3 */}
            <div className="program-card group relative bg-forest border border-sage/30 rounded-2xl overflow-hidden hover:border-sage/60 transition-all duration-500">
              <div className="p-8 md:p-10">
                <div className="w-14 h-14 bg-sage/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-sage/30 transition-colors">
                  <Users className="w-7 h-7 text-sage" />
                </div>
                <h3 className="font-display text-2xl md:text-3xl text-cream font-medium mb-4">
                  Musar & Ethics
                </h3>
                <p className="font-body text-cream/70 leading-relaxed mb-6">
                  Character development in the Novardok tradition, featuring the Rosh 
                  Yeshiva's renowned ethics lectures and personal growth guidance.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Weekly Musar Shiurim
                  </li>
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Personal Guidance (Hashkafa)
                  </li>
                  <li className="flex items-center gap-3 text-cream/80 font-body text-sm">
                    <ChevronRight className="w-4 h-4 text-sage" />
                    Character Development Workshops
                  </li>
                </ul>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-sage/0 via-sage to-sage/0 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            </div>
          </div>
        </div>
      </section>

      {/* Admissions Section */}
      <section ref={admissionsRef} className="py-20 md:py-32 px-4 md:px-8 bg-cream">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
            {/* Content */}
            <div>
              <span className="inline-block text-sage font-body text-sm uppercase tracking-widest mb-4">
                Admissions
              </span>
              <h2 className="font-display text-3xl md:text-5xl text-forest font-medium mb-8">
                Begin Your Journey
              </h2>

              {/* Timeline */}
              <div className="relative">
                <div className="timeline-line absolute left-4 top-0 w-0.5 bg-sage/30" />
                
                <div className="space-y-10">
                  {/* Step 1 */}
                  <div className="timeline-item relative pl-14">
                    <div className="absolute left-0 top-0 w-8 h-8 bg-sage rounded-full flex items-center justify-center">
                      <span className="text-white font-body text-sm font-medium">1</span>
                    </div>
                    <h3 className="font-display text-xl text-forest font-medium mb-2">
                      Requirements
                    </h3>
                    <ul className="space-y-2 font-body text-forest/70 text-sm">
                      <li>• High school diploma or equivalent</li>
                      <li>• Familiarity with Aramaic and Hebrew</li>
                      <li>• Completion of 150 folio pages of Talmud</li>
                      <li>• Competence in Pentateuch and Commentaries</li>
                      <li>• Commitment to Torah observance</li>
                    </ul>
                  </div>

                  {/* Step 2 */}
                  <div className="timeline-item relative pl-14">
                    <div className="absolute left-0 top-0 w-8 h-8 bg-sage rounded-full flex items-center justify-center">
                      <span className="text-white font-body text-sm font-medium">2</span>
                    </div>
                    <h3 className="font-display text-xl text-forest font-medium mb-2">
                      Application Process
                    </h3>
                    <ul className="space-y-2 font-body text-forest/70 text-sm">
                      <li>• Submit application by May 15th</li>
                      <li>• Provide high school records</li>
                      <li>• Include letters of recommendation</li>
                      <li>• Oral examination and interview</li>
                      <li>• Decision within one month</li>
                    </ul>
                  </div>

                  {/* Step 3 */}
                  <div className="timeline-item relative pl-14">
                    <div className="absolute left-0 top-0 w-8 h-8 bg-sage rounded-full flex items-center justify-center">
                      <span className="text-white font-body text-sm font-medium">3</span>
                    </div>
                    <h3 className="font-display text-xl text-forest font-medium mb-2">
                      Financial Information
                    </h3>
                    <ul className="space-y-2 font-body text-forest/70 text-sm">
                      <li>• Tuition: $10,400 per year</li>
                      <li>• Room & Board: $10,920 per year</li>
                      <li>• 67% of students receive financial aid</li>
                      <li>• Institutional scholarships available</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Image */}
            <div className="relative">
              <div className="overflow-hidden rounded-2xl shadow-elevated">
                <img 
                  src="/admissions-img.jpg" 
                  alt="Students on campus" 
                  className="w-full h-[500px] md:h-[700px] object-cover"
                />
              </div>
              {/* Info card */}
              <div className="absolute -bottom-6 -left-6 bg-forest text-cream p-6 rounded-xl shadow-elevated max-w-xs">
                <div className="flex items-center gap-3 mb-3">
                  <Building2 className="w-5 h-5 text-sage" />
                  <span className="font-body text-sm font-medium">Acceptance Rate</span>
                </div>
                <div className="font-display text-4xl text-sage font-semibold">88%</div>
                <p className="font-body text-cream/70 text-xs mt-2">
                  Highly competitive selection process
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section ref={contactRef} className="py-20 md:py-32 px-4 md:px-8 bg-cream">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 md:gap-20">
            {/* Form */}
            <div className="contact-form">
              <span className="inline-block text-sage font-body text-sm uppercase tracking-widest mb-4">
                Contact Us
              </span>
              <h2 className="font-display text-3xl md:text-5xl text-forest font-medium mb-8">
                Get in Touch
              </h2>

              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <label className="block font-body text-sm text-forest mb-2">Name</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 bg-white border border-forest/20 rounded-lg font-body text-forest placeholder-forest/40 focus:outline-none focus:border-sage transition-colors"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block font-body text-sm text-forest mb-2">Email</label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-3 bg-white border border-forest/20 rounded-lg font-body text-forest placeholder-forest/40 focus:outline-none focus:border-sage transition-colors"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label className="block font-body text-sm text-forest mb-2">Message</label>
                  <textarea 
                    rows={5}
                    className="w-full px-4 py-3 bg-white border border-forest/20 rounded-lg font-body text-forest placeholder-forest/40 focus:outline-none focus:border-sage transition-colors resize-none"
                    placeholder="How can we help you?"
                  />
                </div>
                <button 
                  type="submit"
                  className="liquid-fill relative w-full py-4 bg-forest text-cream rounded-lg font-body text-sm font-medium hover:text-cream transition-colors overflow-hidden"
                >
                  <span className="relative z-10">Send Message</span>
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="flex flex-col justify-center">
              <div className="bg-forest rounded-2xl p-8 md:p-12 text-cream">
                <h3 className="font-display text-2xl md:text-3xl font-medium mb-8">
                  Visit Our Campus
                </h3>

                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-sage/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-5 h-5 text-sage" />
                    </div>
                    <div>
                      <div className="font-body text-sm text-cream/60 mb-1">Address</div>
                      <div className="font-body text-cream">
                        802 Hicksville Road<br />
                        Far Rockaway, NY 11691
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-sage/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone className="w-5 h-5 text-sage" />
                    </div>
                    <div>
                      <div className="font-body text-sm text-cream/60 mb-1">Phone</div>
                      <div className="font-body text-cream">
                        (718) 327-7600
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-sage/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail className="w-5 h-5 text-sage" />
                    </div>
                    <div>
                      <div className="font-body text-sm text-cream/60 mb-1">Email</div>
                      <div className="font-body text-cream">
                        tmaslow@yofr.org
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-10 pt-8 border-t border-cream/20">
                  <div className="font-body text-sm text-cream/60 mb-2">EIN Number</div>
                  <div className="font-body text-cream">11-2611716</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-forest py-12 px-4 md:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <a href="#" className="font-display text-2xl text-cream font-medium">
                Derech Ayson
              </a>
              <p className="font-body text-cream/60 text-sm mt-2">
                Rabbinical Seminary
              </p>
            </div>

            <div className="flex flex-wrap justify-center gap-6 md:gap-8">
              <button 
                onClick={() => scrollToSection(aboutRef)}
                className="font-body text-sm text-cream/70 hover:text-cream transition-colors"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection(programsRef)}
                className="font-body text-sm text-cream/70 hover:text-cream transition-colors"
              >
                Programs
              </button>
              <button 
                onClick={() => scrollToSection(admissionsRef)}
                className="font-body text-sm text-cream/70 hover:text-cream transition-colors"
              >
                Admissions
              </button>
              <button 
                onClick={() => scrollToSection(contactRef)}
                className="font-body text-sm text-cream/70 hover:text-cream transition-colors"
              >
                Contact
              </button>
            </div>
          </div>

          <div className="mt-10 pt-8 border-t border-cream/10 text-center">
            <p className="font-body text-cream/50 text-xs">
              © {new Date().getFullYear()} Derech Ayson Rabbinical Seminary. EIN: 11-2611716. 
              All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
